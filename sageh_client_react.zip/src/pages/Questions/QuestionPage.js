import React from 'react';
import Question from '../../components/Questions/Question';

function QuestionsPage() {

    return (
        <Question/>
    )
}

export default QuestionsPage;