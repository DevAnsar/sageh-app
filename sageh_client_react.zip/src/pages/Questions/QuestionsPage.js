import React from 'react';
import Questions from '../../components/Questions/Questions';


function QuestionsPage() {

    return (

            <Questions/>

    )
}

export default QuestionsPage;