import React from 'react';
import IndexComponent from '../../components/Index/Index';

function Index(props) {

    return(
        // <h2>hi ansar</h2>
        <IndexComponent {...props} />
    )
}
export  default Index;