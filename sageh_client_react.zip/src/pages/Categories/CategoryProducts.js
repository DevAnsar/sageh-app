import React from 'react';
import Products from '../../components/Products/Products';


function CategoryProducts() {

    return (
            <Products  />
    )
}

export default CategoryProducts;