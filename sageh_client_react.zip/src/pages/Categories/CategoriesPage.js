import React from 'react';
import Index from '../../components/Categories/Index';

function CategoriesPage() {

    return(
        <Index  />
    )
}
export  default CategoriesPage;